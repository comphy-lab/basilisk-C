`PPR` is licensed under the following terms:

This program may be freely redistributed under the condition that the
copyright notices (including this entire header) are not removed, and
no compensation is received through use of the software. Private,
research, and institutional use is free. You may distribute modified
versions of this code `UNDER THE CONDITION THAT THIS CODE AND ANY
MODIFICATIONS MADE TO IT IN THE SAME FILE REMAIN UNDER COPYRIGHT OF
THE ORIGINAL AUTHOR, BOTH SOURCE AND OBJECT CODE ARE MADE FREELY
AVAILABLE WITHOUT CHARGE, AND CLEAR NOTICE IS GIVEN OF THE
MODIFICATIONS`. Distribution of this code as part of a commercial
system is permissible `ONLY BY DIRECT ARRANGEMENT WITH THE
AUTHOR`. (If you are not directly supplying this code to a customer,
and you are instead telling them how they can obtain it for free, then
you are not required to make any arrangement with me.)

`DISCLAIMER`: Neither I nor: Columbia University, the National
Aeronautics and Space Administration, nor the Massachusetts Institute
of Technology warrant or certify this code in any way whatsoever.
This code is provided "as-is" to be used at your own risk.
