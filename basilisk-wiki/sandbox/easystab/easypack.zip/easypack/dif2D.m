%{
# 2D differentiation matrices and integration from 1D ones 
%}

function [D,l,X,Y,Z,I,NN]=dif2D(d,x,y)

Nx=length(x);
Ny=length(y);
NN=Nx*Ny;

% differentiation
D.x=kron(d.x,speye(Ny));
D.xx=kron(d.xx,speye(Ny));
D.y=kron(speye(Nx),d.y);
D.yy=kron(speye(Nx),d.yy);

% integration
D.w=d.wy(:)*d.wx(:)'; 
D.wx=ones(Ny,1)*d.wx(:)'; 
D.wy=d.wy(:)*ones(1,Nx); 

D.w=reshape(D.w,Ny,Nx);
D.wx=reshape(D.wx,Ny,Nx);
D.wy=reshape(D.wy,Ny,Nx);

% locations
dom=reshape(1:NN,Ny,Nx);
right=dom(2:Ny-1,end);    l.right=right(:);
left=dom(2:Ny-1,1);       l.left=left(:);
top=dom(end,2:Nx-1);      l.top=top(:);
bot=dom(1,2:Nx-1);    l.bot=bot(:);
cor=dom([1 end],[1 end]);     l.cor=cor(:);

l.cbl=cor(1); % top left corner
l.ctl=cor(2); % top right corner
l.cbr=cor(3); % bottom left corner
l.ctr=cor(4); % bottom right corner


[X,Y]=meshgrid(x,y);
Z=spalloc(NN,NN,0); I=speye(NN); 

